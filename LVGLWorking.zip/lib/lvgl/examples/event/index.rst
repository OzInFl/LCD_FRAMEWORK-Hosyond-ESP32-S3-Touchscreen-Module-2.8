
Button click event
"""""""""""""""""""

.. lv_example:: event/lv_example_event_1
  :language: c

Handle multiple events
""""""""""""""""""""""""
.. lv_example:: event/lv_example_event_2
  :language: c


Event bubbling
""""""""""""""""""""""""
.. lv_example:: event/lv_example_event_3
  :language: c


